const api_host = "https://ba28-115-79-25-196.ngrok-free.app"
// const api_host = " http://localhost:6969"
const socket_host = "http://0.tcp.ap.ngrok.io:18615" // tcp trong url doi thanh http nha
// const socket_host = "http://localhost:6969" //chat 1-1
const socket_host_Group = "http://0.tcp.ap.ngrok.io:11029"//chat group
// const socket_host_Group = "http://localhost:7000"//chat group

export default {api_host, socket_host, socket_host_Group};